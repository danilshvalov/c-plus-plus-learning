#include "search_server.h"
#include "iterator_range.h"
#include "test_runner.h"

#include <algorithm>
#include <iterator>
#include <sstream>
#include <iostream>

vector<string> SplitIntoWords(const string& line) {
  istringstream words_input(line);
  return { istream_iterator<string>(words_input), istream_iterator<string>() };
}

SearchServer::SearchServer(istream& document_input) {
  UpdateDocumentBase(document_input);
}

void SearchServer::UpdateDocumentBase(istream& document_input) {
  InvertedIndex new_index;

  for (string current_document; getline(document_input, current_document); ) {
    new_index.Add(move(current_document));
  }

  index = move(new_index);
}

void SearchServer::AddQueriesStream(
  istream& query_input, ostream& search_results_output
) {
  vector<pair<size_t, size_t>> docid_count;
  docid_count.reserve(index.GetSize());
  for (string current_query; getline(query_input, current_query); ) {
    const auto words = SplitIntoWords(current_query);
    docid_count.assign(index.GetSize(), {0, 0});
    for (const auto& word : words) {
      for (const size_t docid : index.Lookup(word)) {
        docid_count[docid] = make_pair(docid, ++docid_count[docid].second);
      }
    }

    auto removable = remove_if(begin(docid_count), end(docid_count), [](pair<size_t, size_t> value) {return value.second == 0;});
    partial_sort(
      begin(docid_count),
      begin(docid_count) + min(5, (int)distance(begin(docid_count), removable)),
      removable,
      [](pair<size_t, size_t> lhs, pair<size_t, size_t> rhs) {
        if (lhs.first == 0) return lhs.second >= rhs.second;
        if (rhs.first == 0) return rhs.second < lhs.second;
        return make_pair(lhs.second, -lhs.first) > make_pair(rhs.second, -rhs.first);
      }
    );

    search_results_output << current_query << ':';

    for (auto it = begin(docid_count); it != removable && distance(begin(docid_count), it) != 5; ++it) {
      search_results_output << " {"
        << "docid: " << it->first << ", "
        << "hitcount: " << it->second << '}';
    }

    search_results_output << endl;
  }
}

void InvertedIndex::Add(const string& document) {
  docs.push_back(document);

  const size_t docid = docs.size() - 1;
  for (const auto& word : SplitIntoWords(document)) {
    index[word].push_back(docid);
  }
}

vector<size_t> InvertedIndex::Lookup(const string& word) const {
  if (auto it = index.find(word); it != index.end()) {
    return it->second;
  } else {
    return {};
  }
}
